#---------------------------------------------------------------------------------------------------------------
#
# Script name:	GetLogFileUsage.ps1
# Version:		2.1
# Author:		Karsten Palmvig
#
# Purpose:		Provide Exchange Server or third party mail server log file statistics for the following:
#
#				Exchange 2010/2013 Server Role Requirements Calculator by Ross Smith IV
#				Exchange Client Network Bandwidth Calculator by Neil Johnson
#
#---------------------------------------------------------------------------------------------------------------
param (
	[Switch]$Help,																							# Display command line help
	[Switch]$File,																							# Use file as input
	$Date = $null,																							# Specify date for log files (default is last 24 hours)
	$Server = $null,																						# Specific server name or "all"
	$Database = $null,																						# Specific database log set (overruled if server is specified)
	$PathFile = ".\paths.txt",																				# Use this file as input if no server or DB is specified, for legacy and non-Exchange support
	$Delimiter = ";"																						# Set whatever separator your Excel defaults to, to be able to open .csv output file directly, also used for pathfile import
)

if ($help -or ($psboundparameters.count -eq 0)) { 
	Write-Output ""
	Write-Output "Use the script with the following command line options:"
	Write-Output ""
	Write-Output ".\GetLogFileUsage.ps1 [-Date DD-MM-YYYY] [-Server <server name> | all] [-Database <db name>] [-File] [-PathFile <file name>] [-Delimiter <char>] [-Help]"
	Write-Output ""
	Write-Output "Defaults are: Read last 24 hours of logfiles, PathFile = .\paths.txt, use semicolon as delimiter."
	Write-Output ""
	Write-Output "Format of the PathFile which is used for legacy or non-Exchange server support is:"
	Write-Output ""
	Write-Output "Server;LogFolderPath"
	Write-Output "<server>;<Path1>"
	Write-Output "<server>;<Path2>"
	Write-Output ""
	Exit 
}

Write-Output "Retrieving LogFolderPaths..."
if ($server -ne $null) {
	if ($server -like "all") { $TransactionLogs = Get-MailboxDatabase | Select-Object Server,LogFolderPath }# Grab LogFolderPath from all Exchange Servers
	else { $TransactionLogs = Get-MailboxDatabase -Server $server | Select-Object Server,LogFolderPath }}  	# Assuming qualified Server name 
elseif ($database -ne $null) { $TransactionLogs = Get-MailboxDatabase $database | Select-Object Server,LogFolderPath } # Assuming qualified DB name
elseif ($file) { $TransactionLogs = Import-Csv $pathfile -Delimiter $Delimiter }									# Use file
else { Write-Output "No usable command line arguments..."; Exit }

if ($date -eq $null) { $start = Get-Date([DateTime]::Now).AddDays(-1); $end = Get-Date }					# Last 24 hours (default)
else { $start = Get-Date($date); $end = $(Get-Date($date)).AddDays(1) }										# Custom date

$outputfile = $pwd.Path + "\output-$((Get-Date -uformat %Y%m%d%H%M).ToString()).csv"						# Log all findings in this file in current folder

$hash = @{
	Time		= $Hour
	Count 		= $Count
	Percent		= $Percent }
$listObj = New-Object PSObject -Property $hash
$Collection = @()

function CountFiles {
	$stream = [System.IO.StreamWriter] $outputfile
	$header = "Server" + $Delimiter + "LogFolderPath"
	foreach ($hour in 0..23) { $header += $Delimiter + "Hour-" + $hour.tostring("00") }
	$stream.WriteLine($header)
	$countCollection = @()
	$firstrun = $true
	
	foreach ($logPath in $TransactionLogs) {
		if ($logpath.server.Name -ne $null) { $logpath.server = $logpath.server.name; $logpath.LogFolderPath = $logpath.LogFolderPath.PathName } # When multivalued entries, take out the middle man to support both file/get-mailboxdatabase
		$output = [string]$logPath.Server + $Delimiter + [string]$logPath.LogFolderPath
		$tmpCollection = @()
		$remotePath = "\\" + $logPath.Server + "\" + $logPath.LogFolderPath.Replace(":","$")
		$files = Get-ChildItem -LiteralPath $remotePath -filter "*.log" | Where-Object { $_.LastWriteTime -ge $start -and $_.LastWriteTime -le $end }
		foreach ($hour in 0..23) {
			$selectFiles = $files | Where-Object { $_.LastWriteTime.hour -eq $hour }
			$output += $Delimiter + [string]$selectFiles.count
			$listObj = New-Object PSObject -Property $hash
			$listObj.Time = $($hour + 1).tostring("00") + ":00"
			$listObj.Count = $selectFiles.count
			$listObj.Percent = 0
			$tmpCollection += $listObj
		}
		$stream.WriteLine($output)
		if ($firstrun) { $countCollection = $tmpCollection } 												# First run, just copy the array 
		else { for ($i=0; $i -le 23; $i++) { $countCollection[$i].count += $tmpCollection[$i].count } } 	# Subsequent runs, add counts
		$firstrun = $false
	}
	$stream.close()
	Return $countCollection
}

function CalcPct($Collection) {
	$sum = 0
	foreach ($element in $Collection) {	$sum += $element.count }											# Sum of log files
	foreach ($element in $Collection) { if ($element.Count -gt 0) { $element.Percent = $("{0:N2}" -f (($element.Count / $sum) * 100)) } } # Calculate and insert percentage
	Return $Collection
}

Write-Output "Collecting data..."
$Collection = CountFiles

Write-Output "Calculating..."
$Collection = CalcPct($Collection)

$Collection | ft Time,Percent,Count -AutoSize
$Collection | ft Percent -AutoSize -HideTableHeaders | Clip

Write-Output "Collected data is available in: $outputfile"
Write-Output "Percent column has been added to your clipboard for easier pasting..."